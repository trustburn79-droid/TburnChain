#!/usr/bin/env node
/**
 * TBURN Validator Node CLI
 * Enterprise-Grade Command Line Interface
 *
 * Usage:
 *   tburn-validator start --config validator.json
 *   tburn-validator init --name "My Validator" --region seoul
 *   tburn-validator status
 *   tburn-validator keys generate
 */
export {};
//# sourceMappingURL=cli.d.ts.map