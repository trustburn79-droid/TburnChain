/**
 * TBURN Validator Status CLI
 * Shows detailed validator status and metrics
 */
export {};
//# sourceMappingURL=status.d.ts.map