/**
 * TBURN Validator Health Check CLI
 * Checks validator and signer health
 */
export {};
//# sourceMappingURL=health.d.ts.map