/**
 * TBURN Validator Registration CLI
 * Registers a new validator with the network
 */
export {};
//# sourceMappingURL=register.d.ts.map